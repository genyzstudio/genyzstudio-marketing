GENYZ STUDIO · SEEDANCE 2.5 PRACTICE PACK

Open images at full size. Use sd25-start.png for the first-clip exercise. Multi-panel sheets are references, not video starting frames: extract one panel before use. Blank TSV forms open in a spreadsheet or text editor. Download your access-filtered bilingual course workbook separately in the classroom.

Mở ảnh ở kích thước đầy đủ. Dùng sd25-start.png cho clip đầu tiên. Bảng nhiều ô dùng để tham chiếu, không đưa nguyên bảng vào ô khung đầu video. Tách một ô trước khi dùng. Các phiếu TSV trống mở bằng bảng tính hoặc trình soạn chữ. Tải sổ khóa học riêng trong lớp để có hướng dẫn và prompt được quyền truy cập.

All supplied images were generated using GPT Image in Codex. They are original teaching assets. No Seedance demonstration video has been generated; no beginner pilot has been performed. Read asset-provenance.json for observed limitations.
Ảnh được tạo bằng GPT Image trong Codex. Chưa có video Seedance minh họa hoặc thử nghiệm với người mới thực tế. Đọc asset-provenance.json để biết giới hạn đã quan sát.
